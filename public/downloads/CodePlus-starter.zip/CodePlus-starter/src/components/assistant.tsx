export function Assistant() {
  return <aside>Ask your selected AI provider</aside>;
}
