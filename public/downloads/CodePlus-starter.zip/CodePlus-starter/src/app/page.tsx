export default function Home() {
  return (
    <main className="hero">
      <span className="eyebrow">CODEPLUS</span>
      <h1>Build faster with your own AI stack.</h1>
      <p>One focused workspace for browser and desktop.</p>
      <div className="actions">
        <button>Start building</button>
        <button className="secondary">View docs</button>
      </div>
    </main>
  );
}
