# CodePlus project

Built with CodePlus. Choose a local, Codex, or Gemini model in Studio settings.

## Run

```bash
npm install
npm run dev
```
Open http://localhost:3000 — preview in CodePlus will show the same page.
